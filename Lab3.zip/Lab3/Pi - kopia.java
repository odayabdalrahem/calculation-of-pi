import java.math.BigInteger;  
/**
 * Write a description of class Pi here.
 * 
 * @author Theo  Odai
 */

public class Pi {

    public static void main(String[] args) {
        int decimalCount = 17;
        if (args.length > 0) {
            decimalCount = Integer.valueOf(args[0]);
        }

        RatNum res = new RatNum(0,1);
        // ersätt följande två rader med din lösning

        for (int k = 0; k <= decimalCount; k++) {
    
            RatNum a = new RatNum(1,16);
            a = a.pow(k);
            
            RatNum b1 = new RatNum(4, ((8 * k) + 1));
            RatNum b2 = new RatNum(2, ((8 * k) + 4));
            RatNum b3 = new RatNum(1, ((8 * k) + 5));
            RatNum b4 = new RatNum(1, ((8 * k) + 6));
            
            b1 = b1.sub(b2);
            b1 = b1.sub(b3);
            b1 = b1.sub(b4);
            
            a = a.mul(b1);
        
            res = res.add(a);
        }
        
        // kod för utskriften (behöver inte ändras)
        // denna kod antar att den första decimalen av res är något annat än 0
        // (i pi är den första decimalen 1)
        RatNum m = new RatNum(1,1);
        RatNum ten = new RatNum(10,1);
        for (int k=0; k < decimalCount; k++) {
            m = m.mul(ten);
        }
        System.out.print("pi = ");
        String intPart = res.toIntString();
        System.out.print(intPart);
        System.out.print(".");
        RatNum digits = res.sub(RatNum.parse(intPart));
        System.out.print(digits.mul(m).toIntString());
        System.out.println("...");
    }

}      
